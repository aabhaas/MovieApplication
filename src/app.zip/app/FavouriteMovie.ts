export class FavouriteMovie{
    posterPath:string;
    releaseDate: string;
    orignalTitle:string;
}