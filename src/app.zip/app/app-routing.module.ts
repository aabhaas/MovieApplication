// import { NgModule }             from '@angular/core';
// import { RouterModule, Routes } from '@angular/router';

// import { FavMovieComponent } from './fav-movie/fav-movie.component';
// import {MovieSearchComponent} from './searchMovie/searchmovie.component'
// import { ConnectorComponent } from './connector/connector.component';
// import { LoginComponent } from './login/login.component';
// import { RegisterComponent } from './register/register.component';


// const routes: Routes = [
//     {path:'',component:MovieSearchComponent},
//     {path:'movie/:value',component:MovieSearchComponent},
//     {path:'favMovie',component:FavMovieComponent},
//     {path:'connector/:value',component:ConnectorComponent},
//     {path:'login',component:LoginComponent},
//     {path:'register',component:RegisterComponent}
    
// ];

// @NgModule({
//   imports: [ RouterModule.forRoot(routes) ],
//   exports: [ RouterModule ]
// })
// export class AppRoutingModule {}

